#include <stdio.h>

int main(){
    printf( "Sergio Rodriguez Ramirez\n");
    printf( "progCal\n");

    return 0;
}
