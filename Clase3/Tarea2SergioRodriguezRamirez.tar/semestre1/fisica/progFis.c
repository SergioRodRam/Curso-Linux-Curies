#include <stdio.h>

int main(){
    printf( "Sergio Rodriguez Ramirez\n");
    printf( "progFis\n");

    return 0;
}
