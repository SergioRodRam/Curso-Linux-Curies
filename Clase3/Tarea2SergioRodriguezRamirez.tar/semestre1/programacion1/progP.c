#include <stdio.h>

int main(){
    printf( "Sergio Rodriguez Ramirez\n");
    printf( "progP\n");

    return 0;
}
